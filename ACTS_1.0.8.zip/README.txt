Army Conformance Test Suite (ACTS)

ACTS is a modification of ADL's SCORM 2004 Test Suite (CTS).
It includes the additions of Army-specific rules and outputs,
and removes testing features not pertinent to IMI content development.


System Requirement:

* Windows 7 or Windows 10
* Microsoft Internet Explorer 11, or Microsoft Edge capable of IE mode
* Java 8 Run-Time Environment (JRE) 32-bit (version 1.8.0u271 or up)
  https://www.oracle.com/java/technologies/javase-jre8-downloads.html


To launch ACTS:

* Open ACTS.htm with Internet Explorer or Microsoft Edge