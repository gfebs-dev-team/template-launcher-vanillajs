// Global variable declarations
var testComplete;
var testType;
var pifType;
var timeoutValue;
var assetTimeoutValue;
var doMDTest = true;
var extensionSchemaLocation = " ";
var allTestingComplete = false;

// Variables for SCO Test Suite Module
var doSCOTest = true;
var studentid = "User01";
var studentname="Joe Student";
var credit = "credit";
var mode = "normal";
var scoWin = null;
var scoToTest;
var overallSCOResult = true;
var inSCOTest = false;
var finishedCalled = false;
var scosLaunched = 0;
var launchInfo;

var doManifestOnly = false;

var supressLabel = true;

var useOldLog = false;
var oldLogFile;

// Variable that holds the reference to the Test Suite API
var API_1484_11_Impl = null;
var API_1484_11;

var API; // Trap for 1.2 API

// Variable that holds the reference to the Content Package Driver
var driver = null;

// Define the log message type constants

//  0 = informational (diagnostic, trace, etc.)
var _INFO = "0";
//  1 = warning
var _WARNING = "1";
//  2 = conformance check passed
var _PASSED = "2";
//  3 = conformance check failure
var _FAILED = "3";
//  4 = test suite termination due to
var _TERMINATE = "4";
//  5 = subject is found to be conformant
var _CONFORMANT = "5";
//  9 = other
var _OTHER = "9";
// 10 = header
var _HEADER = "10";

// constants for which log to write to
var _BOTH = "0";
var _DLOG = "1";
var _SLOG = "2";

function initInstructions()
{
    scrollIntoView("topOfForm");
    $$("form").pname.value = "";
    $$("form").pversion.value = "";
    $$("form").pvname.value = "";

    disable("end");

    $$("xmlfile").addEventListener("input", activateValidate);

    testComplete = false;

    // Set up the API
    // Set up the content package driver
    // Delay for netscape 6 compatibilty
    DetectBrowser();
    API_1484_11_Impl = document.APIImplementation;
    driver = document.contentPackageDriver;

    window.setTimeout("driver.setIsBrowserNetscape(Netscape)", 100);
}

function activateValidate()
{
    $$("Continue6").disabled = !$$("xmlfile").value;
}

/**
* Method:  step2()
*
* Description
*   Handles the interaction of the user for the first step of this test.
*
*/
function step2()
{
    var type = checkedValue("testTypeChoice");

    if ( type == "manifest" )
    {
        doSCOTest = false;
    }

    if ( type != "" )
    {
        testType = type;

        show("status_ok_2");
        show("row_step_3");
        show("step_3");
        scrollIntoView("row_step_3");

        disable("Continue2");
        disable("step2Rad1");
        disable("step2Rad2");
    }
    else
    {
        show("status_fail_2");
        alert("The type of SCORM Content Package Profile being tested " +
            "must be selected." );
        hide("status_fail_2");
    }
}

/**
* Method:  step3()
*
* Description
*    Handles the interaction of the user for the second step of this test
*/
function step3()
{
    var packageType = "";
    var stepFour = $$("step_6");
    var type = checkedValue("pifTypeChoice");

    if ( type != "" )
    {
        pifType = type;

        show("status_ok_3");

        show("row_step_6");
        show("step_6");
        scrollIntoView("row_step_6");

        disable("Continue3");
        disable("step3Rad1");
        disable("step3Rad2");

        // Text dependent upon radio selection in Step 2
        packageType = checkedValue("testTypeChoice");

        if (packageType == "non-pif")
        {
            stepFour.insertAdjacentHTML("beforeBegin",
                                        "<p><div class='question'>Select the" +
                                        " imsmanifest.xml file to be " +
                                        "tested:</div></p>");
        }
        if (packageType == "pif")
        {
            stepFour.insertAdjacentHTML("beforeBegin",
                                        "<p><div class='question'>Select the" +
                                        " Content Package to be tested:</div></p>");
        }
    }
    else
    {
        show("status_fail_3");
        alert( "The type of SCORM Package being tested must be selected." );
        hide("status_fail_3");
    }
}

/**
* Method:  step7()
*
* Description
*     Handles the validation of the time out value entered by the user
*     and prepares the form for the next step of the test.
*
*/
function step7()
{
    timeoutValue = $$("inittimeout").value;
    assetTimeoutValue = $$("assetinittimeout").value;
    var timeouterror = false;

    if (isNaN(timeoutValue) || isNaN(assetTimeoutValue) )
    {
        errMsg += "You must enter a numeric Initialize Timeout " +
                    "value between 0 and 999.\n";
        timeouterror = true;
    }
    else
    {
        // Now check to see if the timeoutValue is a number that is
        // greater than 0
        if (timeoutValue < 0 || assetTimeoutValue < 0)
        {
            errMsg += "The Initialize Timeout value must be between " +
                        "0 and 999.\n";
            timeouterror = true;
        }
    }

    if ( timeouterror == false )
    {

        show("status_ok_7");
        show("row_step_8");
        show("step_8");
        scrollIntoView("row_step_8");

        disable("Continue7");
        disable("inittimeout");
        disable("assetinittimeout");
    }
    else
    {
        show("status_fail_7");
        alert( "The Initialize time out value is invalid." );
        hide("status_fail_6");
    }
}

/**
* Method:  step8()
*
* Description:
*          Handles the validation of the initialization data entered by
*          the user and prepares the form for the next step of the test.
*/
function step8()
{
    if ( $$("f_studentid").value != "" )
    {
        studentid = $$("f_studentid").value;
    }

    if ( $$("f_studentname").value != "" )
    {
        studentname = $$("f_studentname").value;
    }

    if ( $$("f_creditflag").value != "" )
    {
        credit = $$("f_creditflag").value;
    }

    if ( $$("f_lessonmodeflag").value != "" )
    {
        mode = $$("f_lessonmodeflag").value;
    }

    disable("Continue8");
    disable("f_studentid");
    disable("f_studentname");
    disable("f_creditflag");
    disable("f_lessonmodeflag");

    show("status_ok_8");
    show("row_step_9");
    show("step_9");
    scrollIntoView("row_step_9");

    // pull the first SCO for launch
    cp_loadLaunchInfo();
}

/**
* Method:  startTest()
*
* Description
*    Set up the view for the first step of this test
*
*/
function startTest()
{
    var cDate = new Date;
    var spacers =
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

    var form = $$("form");
    driver.setTestIDInfo(cDate.toLocaleString(),
                        form.pname.value,
                        form.pversion.value,
                        form.pvname.value);

    //gets the row step 1 element
    var rowstep2_Elem = $$("row_step_2");

    show(rowstep2_Elem);

    rowstep2_Elem.scrollIntoView();
    form.continue0.disabled = true;
    form.pname.readOnly = true;
    form.pversion.readOnly = true;
    form.pvname.readOnly = true;

    show("status_ok_1");
}

/**
 * Method:  cp_loadLaunchInfo()
 *
 * Description
 *    load SCO's information (title, minNormalizedMeasure, etc.) and
 *    set default assessment option
 */
function cp_loadLaunchInfo()
{
    if (doSCOTest) {
        launchInfo = driver.getNextLaunchLine();
        // check whether this SCO is assessment
        var minNormalizedMeasure = driver.getMinNormalizedMeasure();
        var assessment = $$("assessment");
        var isAssessment
            = assessment.disabled
            = assessment.checked
            = minNormalizedMeasure !== "";
        $$("launch_info").innerHTML = isAssessment
            ? "This SCO has a minimal normalized measure of " +
              minNormalizedMeasure +
              ", therefore it is an assessment."
            : "This SCO does not have a minimal normalized measure. " +
              "Check the following checkbox if you want to test it as an assessment.";
    }
}

/**
*
* Method:  cp_launchSCO()
*
* Description
*    Retrieves the next sco location for launch
*
*/
function cp_launchSCO()
{
    inSCOTest = true;
    var cDate = new Date;
    var logMsg;
    var commfrlmscomment = "";
    var commfrlmslocation = "";
    var commfrlmsdatetime = "";
    var masteryscore = "";
    var maxtimeallowed = "";

    // Disable the Launch SCO button
    disable("launchsco");
    enable("end");

    // Constructs the lms comments string
    var commentsFromLMS = "[1c]" + commfrlmscomment + "[2l]" +
        commfrlmslocation + "[3t]" + commfrlmsdatetime + "[EOC]";


    if ( doSCOTest )
    {
        logMsg = "Initiating SCO Test Suite <br>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
            "Test Identification Information:<br>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date: " +
                cDate.toLocaleString() + "<br>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Resource: ";

        // var launchInfo = driver.getNextLaunchLine();
        var launchPath = launchInfo.split("~")[0];
        var launchType = launchInfo.split("~")[1];

        driver.writeHeaderInfo(logMsg, launchPath);


        // Set the launch type in the SCO applet
        APIImplementation.setResourceType(launchType);
        APIImplementation.setIsScoPartOfCP(true);

        var timeVal;
        if ( launchType.toLowerCase() == "asset" )
        {
            timeVal = assetTimeoutValue;
        }
        else
        {
            timeVal = timeoutValue;
        }

        var dataFromLMS = driver.getDataFromLMS();
        var timeLimitAction = driver.getTimeLimitAction();
        var completionThreshold = driver.getCompletionThreshold();
        var objectivesData = driver.getObjectivesData();
        var dataData = driver.getDataData();

        APIImplementation.startTest(
            launchPath,
            timeVal,
            studentid,
            studentname,
            credit,
            mode,
            dataFromLMS,
            commentsFromLMS,
            objectivesData,
            dataData,
            masteryscore,
            maxtimeallowed,
            timeLimitAction,
            completionThreshold);
    }
    else
    {
        // Disable sco buttons - no sco to launch
        show("status_fail_6");
    }
}

/**
*
* Method:  launchSCO()
*
* @param scoLoc
*    Location of the sco being launched
*
* @param errors
*    Contains the errors that have occured during the sco validation
*
* Description
*     Launches the scos found in the content package
*
*
*/
function launchSCO( scoLoc, errors )
{
    scoToTest = scoLoc;

    scosLaunched = scosLaunched + 1;

    // Replace the slashs for consistency
    scoToTest = scoToTest.replace(/\\/g, "/");

    writeLogEntry(_BOTH, _INFO, "Attempting to Launch Resource: " + scoToTest);

    finishedCalled = false;

    // JavaScript SCORM 2004 API object defined
    API_1484_11 = new APIObject2004();

    // JavaScript SCORM 1.2 API object defined - to catch wrong 1.2
    API = new APIObject12();

    try {
        scoWin = window.open(scoToTest, "scoWin");
    } catch (e) {
        alert("ERROR: Cannot open the SCO window.");
    }
}

/**
*
* Method:  endTest()
*
* @param iReportResults
*        true if reporting  Conformance Results (will be false if timeout exceeded)
*
* Description
*    This method completes the Content Package test if there are
*    no SCOs remaining to be spawned for validation.
*
*/
function endTest(iReportResults)
{
    var scoConformance;
    APIImplementation.endTest(false, true, (iReportResults == "true"),
        $$("assessment").checked);
    scoConformance = APIImplementation.isTestConformant();

    driver.setSCOConformance(scoConformance);

    if (scoWin != null)
    {
        scoWin.close();

        // If there are more SCOs to launch and we're still reporting conformance results
        if ( (driver.allScosTested() == "false") && (iReportResults == "true") )
        {
            // Get information from the SCO RTE Driver on whether or not the
            // SCO is conformant
            alert("Ready to test next SCO.");
            finishedCalled = false;
            cp_loadLaunchInfo();
            cp_launchSCO();
        }
        else
        {
            // Disable all the buttons
            disable("launchsco");
            disable("end");
            hide("abort_para");

            if (iReportResults == "true")
            {
                driver.completeTest( doSCOTest, doMDTest, supressLabel );
            }
            else
            {
                // Suppress conformance label as iReportResults is false
                driver.completeTest( doSCOTest, doMDTest, true );
            }
            show("status_ok_9");
            allTestingComplete = true;
        }
    }
}

/**
* Function: abortTest()
*
*  Description:
*    This function is called when the Abort Test button is pressed on
*    the Instructions web page.  This function closes the open SCO
*    window (if it's open), disables the buttons and then calls
*    terminateTest() to end the processing of this package.
*/
function abortTest()
{
    // If the SCO Window is open - close it
    if (scoWin != null)
    {
        scoWin.close();
    }

    // Disable the buttons
    disable("launchsco");
    disable("end");
    disable("abort");

    writeLogEntry(_SLOG, _FAILED,
                    "Content Package Conformance Test has been aborted");
    writeLogEntry(_SLOG, _FAILED, "The Content Package is Non-Conformant");

    terminateTest();
    show("status_fail_9");
    abortCPTest();
}

/**
*  Method:  abortCPTest()
*
* Description:
*   Called when the Abort Test button is pressed or when the Test Suite
*   is closed while processing (e.g. clicking the "x" while its running).
*/
function abortCPTest()
{
    // Add the end tag data for the aborted SCO test log
    // Only write end tag if a SCO log has been created
    if ( scosLaunched > 0 )
    {
        writeLogEntry(_DLOG, "8", "");
    }

    // Call CP Driver to close Summary Log
    driver.abortCPTest();
}

/**
*  Method:  terminateTest()
*
* Description:
*    This function is called when the test is either completed or an
*    unrecoverable condition has been met.  Unrecoverable conditions
*    may include fatal test software errors, test step failure, or test
*    subject errors.
*
*/
function terminateTest()
{
    // Disable all the controls
    finishedCalled = true;

    if ( driver.allScosTested() == "false" )
    {
        testComplete = true;
    }
}

/**
* Method:  writeLogEntry(log, type, msg)
*
* @param log
*    log to which to write
*
* @param type
*    category of message
*
* @param msg
*      actual message text
*
* Description
*   Interface function to write messages to the log based on the type.
*
*/
function writeLogEntry(log, type, msg)
{
    driver.doWriteLogEntry(log, type, msg);
}

/**
* Method:  confirmQuit(
*
* Description:
*       Provides an option to cancel a quit.
*
*/
function confirmQuit()
{
    if (testComplete == false || allTestingComplete == false)
    {
        // Writes the end tags to the Logs
        abortCPTest();
        var msg = "The test is not complete.  If you leave this page, \n" +
            "the test will be terminated and you will lose the test log.";
        return msg;
    }
}

/**
* Method:  validate()
*
* Description:
*   Use the applet's public method, passing the name of the file entered
*   by the user.  The following is intended to simulate what the
*    validation function might do.
*
*/
function validate()
{
    var manifestFile = $$("xmlfile").value;

    if (manifestFile.indexOf("fakepath") > 0) {
        $$("include-path-instruction").style.display = "block";
        return;
    }

    // last index in the array should be the filename we want to verify
    var splits = manifestFile.split("\\");
    var filename = splits[splits.length-1];

    // making the extension lower case for easy verification
    filename = filename.substring(0, (filename.length-3)) +
               filename.substring((filename.length-3), filename.length).toLowerCase();

    var ext = manifestFile.substr((manifestFile.length-4), manifestFile.length);
    ext = ext.toLowerCase();

    if ( manifestFile == "" )
    {
        return;
    }
    else if ( (filename == "imsmanifest.xml" && testType == "non-pif") ||
              (ext == ".zip" && testType == "pif" ) )
    {
        disable("xmlfile");
        disable("Continue6");

        alert("The Content Package Test initiated.  " +
            "This may take a few minutes, please be patient.");

        driver.startValidateTest( manifestFile, testType, pifType,
                                  extensionSchemaLocation, doMDTest,
                                  doSCOTest, doManifestOnly );

        var isValid = driver.isManifestConformant();
        supressLabel = !driver.isLabelShown();

        if ( isValid == true )
        {
            show("status_ok_6");

            if ( doSCOTest  && driver.doSCOsExist() )
            {
                openBranching();
            }
            else
            {
                testComplete = true;
                driver.completeTest( doSCOTest, doMDTest, supressLabel );
            }
        }
        else
        {
            show("status_fail_6");
            testComplete = true;
            driver.completeTest( doSCOTest, doMDTest, supressLabel );
        }
    }
    else
    {
        // tell the user the error and reset the file input.
        if ( testType === "non-pif" )
        {
            alert("Please select an imsmanifest.xml file.");
        }
        else if ( testType === "pif" )
        {
            alert("Please select a .zip file.");
        }
        // reset the file input box
        $$("step_6").innerHTML = $$("step_6").innerHTML;
    }
}

function openBranching()
{
    show("branching-head");
    show("branching");
    scrollIntoView("branching-head");
}

function afterCP()
{
    disable("br-continue");
    switch (checkedValue("nextStep")) {
        case "sco test":
            openSCOTest();
            break;
        case "parse log":
            openParseLog();
            break;
    }
}

function openSCOTest()
{
    show("SCODivide");
    show("row_step_7");
    show("step_7");
    remove("parselog-head");
    remove("parselog");
    remove("parsesco");
    scrollIntoView("SCODivide");

    var type = checkedValue("pifTypeChoice");

    if ( type != "resource" )
    {
        show("asset");
    }
}

function openParseLog()
{
    show("parselog-head");
    show("parselog");
    scrollIntoView("parselog-head");
    useOldLog = true;
}

/**************************************************************************
 **
** Function: API Object
** Inputs:  Catch all for 1.3 SCO calls
** Return:  none
**
** Description:
** APIObject is a JavaScript Object used to catch all the 1.2 calls
**
**************************************************************************/
function APIObject2004()
{
    this.Initialize = Initialize;
    this.Terminate = Terminate;
    this.GetValue = GetValue;
    this.SetValue = SetValue;
    this.Commit = Commit;
    this.GetLastError = GetLastError;
    this.GetErrorString = GetErrorString;
    this.GetDiagnostic = GetDiagnostic;
}

/**************************************************************************
**
** Function: API Object
** Inputs:  Catch all for 1.3 SCO calls
** Return:  none
**
** Description:
** APIObject is a JavaScript Object used to catch all the 1.2 calls
**
**************************************************************************/
function APIObject12()
{
    this.LMSInitialize = version12APICP;
    this.LMSFinish = version12APICP;
    this.LMSGetValue = version12APICP;
    this.LMSSetValue = version12APICP;
    this.LMSCommit = version12APICP;
    this.LMSGetLastError = version12APICP;
    this.LMSGetErrorString = version12APICP;
    this.LMSGetDiagnostic = version12APICP;
}
