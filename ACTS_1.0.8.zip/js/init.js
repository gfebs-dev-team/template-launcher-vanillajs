var $, $$;
var loaded = {};
var initialized = false;

function getHome()
{
    return decodeURI(location.pathname.substr(1))
        .replace(/\/ACTS.htm$/,"")
        .replace(/\//g, "\\");
}

/**
* Method:  initialize()
*
* Description:
*   Set up intitial values and view for this test
*
*/
function initialize()
{
    if (isEdge()) {
        document.getElementById("loading").innerHTML
            = "<div><h1>You are using Microsoft Edge</h1>"
            + "Please reload the page in Internet Explorer mode.</div>"
    } else if (!isIE()) {
        document.getElementById("loading").innerHTML
            = "<div><h1>This browser is not supported</h1>"
            + "Please open the file with <b>Internet Explorer</b> or <b>Microsoft Edge</b>.</div>"
    }
}

function isEdge()
{
    if ("userAgentData" in window.navigator) {
        return window.navigator.userAgentData.brands.some(
            function (brand_version) {
                return brand_version.brand === "Microsoft Edge"
            }
        )
    }
    return false
}

function isIE()
{
    return navigator.userAgent.indexOf("MSIE") > -1 ||
           navigator.userAgent.indexOf("rv:") > -1
}

/**
* Method:  loadComplete()
*
* Description:
*    This function is called when the applets have been loaded for the
*    test. The continue button will then be made visible.
*
*/
function loadComplete(component)
{
    loaded[component] = true;
    if (! allLoaded()) return;

    if (initialized) return;
    initialized = true;

    $ = document.querySelector.bind(document);
    $$ = document.getElementById.bind(document);

    initInstructions();
    initParse();
    initLogs();

    enable("continue0");
    $$("loading").style.display = "none";
}

function allLoaded()
{
    return loaded.driver && loaded.sco && loaded.log;
}

/**************************************************************************
** Utility functions
**************************************************************************/

function show(element)
{
    element = getElement(element);
    if (element) {
        element.style.visibility = "visible";
    }
}

function hide(element)
{
    element = getElement(element);
    if (element) {
        element.style.visibility = "hidden";
    }
}

function remove(element)
{
    element = getElement(element);
    if (element) {
        element.parentElement.removeChild(element);
    }
}

function disable(element)
{
    element = getElement(element);
    if (element) {
        element.disabled = true;
    }
}

function enable(element)
{
    element = getElement(element);
    if (element) {
        element.disabled = false;
    }
}

function scrollIntoView(element)
{
    element = getElement(element);
    if (element) {
        element.scrollIntoView();
    }
}

function getElement(element)
{
    if (typeof element == "string") {
        element = $$(element);
    }
    if (element instanceof HTMLElement) {
        return element;
    }
    return null;
}

function checkedValue(name)
{
    return $("input[name='" + name + "']:checked").value;
}
