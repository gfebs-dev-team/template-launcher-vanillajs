var parser;

function initParse()
{
    parser = driver;
    $$("logfile").addEventListener("input", activateParse);
}

function activateParse()
{
    $$("parse-btn").disabled = !$$("logfile").value;
}

function parseLog()
{
    disable("parse-btn");
    disable("logfile");

    var logFile = $$("logfile").value;

    oldLogFile = logFile;
    useOldLog = true;

    show("SCODivide");
    remove("row_step_7");
    remove("row_step_8");

    show("status_ok_8");
    show("row_step_9");
    show("step_9");
    remove("sco_instruction");
    remove("launchsco");
    remove("end");
    remove("abort_para");
    scrollIntoView("row_step_9");

    // pull the first SCO for launch
    cp_loadLaunchInfo();
}

function parseSCO()
{
    // alert("Parse SCO")
    disable("parsesco");
    parser.startParse(oldLogFile, $$("assessment").checked);
}

function writeParserResult(messages)
{
    logsWriteLogEntry(_INFO, messages);
    testComplete = true;
    driver.completeTest( doSCOTest, doMDTest, false );
}
