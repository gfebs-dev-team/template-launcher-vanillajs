//variables to control the Test Suite Version
var adl;
var scorm;
var testsuite;
var logTitleText;

// Variable used to hold the contents of the Log for Netscape browsers
var navTempText = "";

// variable to hold the html content of the log
var htmlcontent;

// variable to hold the logInterface applet object
var appObj;

function initLogs()
{
   browserOK = DetectUnsupportedBrowser();

   appObj = $$('logInterface');

   window.setTimeout(displayInterface, 1000);
}

/**
 * Function: displayInterface()
 *
 * Description: This function is responsbile for initalizing the applet
 *
 */
function displayInterface()
{
   adl = appObj.getADLTitle();
   scorm = appObj.getSCORMTitle();
   testsuite = appObj.getTSTitle();

   var
   logTitleText =  "      <table width=\"100%\">\n";

   logTitleText += "         <tr>\n";
   logTitleText += "            <td class=\"ADLTitle\">\n";
   logTitleText += adl;
   logTitleText += "            </td>\n";
   logTitleText += "         </tr>\n";

   logTitleText += "         <tr>\n";
   logTitleText += "            <td class=\"logTitle\">\n";
   logTitleText += scorm;
   logTitleText += "            </td>\n";
   logTitleText += "         </tr>\n";

   logTitleText += "         <tr>\n";
   logTitleText += "            <td class=\"logTitle\">\n";
   logTitleText += testsuite;
   logTitleText += "            </td>\n";
   logTitleText += "         </tr>\n";

   logTitleText += "         <tr>\n";
   logTitleText += "            <td class=\"logTitle\">\n";
   logTitleText += "            </td>\n";
   logTitleText += "         </tr>\n";

   logTitleText += "      </table>\n";
   logTitleText += "      <br />\n";

   $$("logText").insertAdjacentHTML("BeforeEnd", logTitleText);

   // Write Environment Information to the Screen
   appObj.writeEnvInfo(browserVersion, browserName, browserOK);
}

/**
 * Function: logsWriteLogEntry
 *
 * @param type
 *     category of message
 *
 * @param msg
 *     actual message text
 *
 * Description:  This function is responsible for formatting and
 *              writing out the log text to the Log.htm page.
 */
function logsWriteLogEntry(type, msg)
{
   var displayMsg = "<table width=\"100%\"><tr>";
   var logtext_elem = $$('logText');
   var needsPrinted = true;

   if (msg.search("3&lt;sup style=&quot;font-size:0.8em;&quot;&gt;rd&lt;/sup&gt;") != -1)
   {
      msg = msg.replace(/3&lt;sup style=&quot;font-size:0.8em;&quot;&gt;rd&lt;\/sup&gt;/g,"3<sup>rd</sup>");
   }
   if (type == 6)
   {
      var bar = "<hr />";
      displayMsg += "<td>    <div id=\"defaultOther\">&nbsp;&nbsp;&nbsp;";
      logtext_elem.insertAdjacentHTML("BeforeEnd", displayMsg);
      logtext_elem.insertAdjacentHTML("BeforeEnd", bar);
      logtext_elem.insertAdjacentText("BeforeEnd", msg);
      logtext_elem.insertAdjacentHTML("BeforeEnd", bar);
      logtext_elem.insertAdjacentHTML("BeforeEnd",
                                      "</div></td></tr></table>\n");
      needsPrinted = false;
   }
   else if ( msg == "<hr />" )
   {
     logtext_elem.insertAdjacentHTML("BeforeEnd",
                                     "<br />" + msg + "<br />");
     needsPrinted = false;
   }

   if ( needsPrinted )
   {
      displayMsg += msg + "</tr></table>\n";
      logtext_elem.insertAdjacentHTML("BeforeEnd", displayMsg);
   }

   //have to hide the applet while scrolling to avoid image refresh problems
   hide('logbuttons');
   logtext_elem.scrollIntoView(false);
   show('logbuttons');
}


/**
 * Function: saveLog()
 *
 * Description
 *    Function used to save the Log content
 */
function saveLog()
{
   var currentTime = new Date();
   var hour = currentTime.getHours();
   var min = currentTime.getMinutes();
   var month = currentTime.getMonth();
   // add one to the Month - JavaScript Months start 0 - Jan, 1 - Feb.
   month = month + 1;
   var date = currentTime.getDate()

   // Build Default file name: Example - TestLog_7_12_1059.htm
   var time = "TestLog_" + month + "_" + date + "_" + hour + min

   readInLog();
   appObj.saveLogContentIE(htmlcontent,time);
}


/**
 *  Function: readInLog()
 *
 * Description:
 *    This function reads the contents of the log frame and
 *    stores them in the "htmlcontent" variable
 */
function readInLog()
{
   htmlcontent = "<html>\n";
   htmlcontent += "   <head>\n";
   htmlcontent += "      <meta http-equiv=\"expires\" content=\"Tue, 20 Aug 1999 01:00:00 GMT\">\n";
   htmlcontent += "      <meta http-equiv=\"Pragma\" content=\"no-cache\">\n\n";
   htmlcontent += "      <title>Test Log</title>\n";
   htmlcontent += "      <style>\n";
   htmlcontent += "         table.logTitle\n";
   htmlcontent += "         {\n";
   htmlcontent += "            font-size: 12px;\n";
   htmlcontent += "            font-family :  Arial, Helvetica, sans-serif;\n";
   htmlcontent += "            color: Purple;\n";
   htmlcontent += "            text-align: center;\n";
   htmlcontent += "         }\n";
   htmlcontent += "      </style>\n";
   htmlcontent += "   </head>\n\n";
   htmlcontent += "   <body>\n";

   htmlcontent += $$("logText").innerHTML;
   htmlcontent += "   </body>\n</html>";
}

/**
 * Function: setUp()
 *
 * Description
 *     This function sets up the variable used to hold the Log's content
 *     (if using Netscape)
 *
 */
function setUp()
{
   navTempText = "<html>\n";
   navTempText += "   <head>\n";
   navTempText += "      <meta http-equiv=\"expires\" content=\"Tue, 20 Aug 1999 01:00:00 GMT\">\n";
   navTempText += "      <meta http-equiv=\"Pragma\" content=\"no-cache\">\n\n";
   navTempText += "      <title>Test Log</title>\n";
   navTempText += "      <style>\n";
   navTempText += "         table.logTitle\n";
   navTempText += "         {\n";
   navTempText += "            font-size: 12px;\n";
   navTempText += "            font-family :  Arial, Helvetica, sans-serif;\n";
   navTempText += "            color: Purple;\n";
   navTempText += "            text-align: center;\n";
   navTempText += "         }\n";
   navTempText += "      </style>\n";
   navTempText += "   </head>\n\n";
   navTempText += "   <body>\n";
   navTempText += logTitleText;
}

/**
 * Function: legendLog()
 *
 * Description
 *    Function used to view a pop-up of the legend for the log.
 *
 */
function legendLog()
{
   window.open("LogLegend.htm", "LogLegend", "height=325,width=420");
}
