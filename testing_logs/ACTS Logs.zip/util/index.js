// add event listener to item headers to expand/collapse
Array.prototype.forEach.call(document.querySelectorAll('.item .header'), function (header) {
  header.addEventListener('click', function (e) {
    header.parentElement.classList.toggle('show-details')
    header.nextElementSibling.scrollIntoView()
  })
})

// open all links in new window
Array.prototype.forEach.call(document.querySelectorAll('a[href]'), function (link) {
  link.setAttribute('target', '_blank')
})

// expand all
document.getElementById('expand-all').addEventListener('click', function (e) {
  Array.prototype.forEach.call(document.querySelectorAll('.item'), function (item) {
    item.classList.add('show-details')
  })
})

// collapse all
document.getElementById('collapse-all').addEventListener('click', function (e) {
  Array.prototype.forEach.call(document.querySelectorAll('.item'), function (item) {
    item.classList.remove('show-details')
  })
})
